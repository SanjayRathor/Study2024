# $Id$

# Specify if host has sound device, or test should be performed using sound device
HAS_SND_DEV = 0
