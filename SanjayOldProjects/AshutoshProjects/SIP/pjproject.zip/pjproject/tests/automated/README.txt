This directory contains files to run automated/unattended tests for PJSIP. 

See https://trac.pjsip.org/repos/wiki/AutomatedTesting for more info.

