
/* 
 *  !! OIY OIY !!
 *
 *  The purpose of this file is only to get pjsip-test linked. I haven't
 *  actually tried to run pjsip-test on RTEMS!!
 *
 */

#include "../../pjlib/src/pjlib-test/main_rtems.c"


