
///Here need to define the Global package constant
const val androidApp = "com.android.application"
const val androidLib = "com.android.library"

object Versions {
    const val min_sdk = 19
    const val target_sdk = 32
    const val compile_sdk = 32
    // Plugins
    const val kotlin = "1.6.10"
}

object Deps {
    //const val kotlin_gradle_plugin = "org.jetbrains.kotlin:kotlin-gradle-plugin:${Versions.kotlin_gradle_plugin}"
    ///const val junit = "junit:junit:${Versions.junit}"
    //const val material = "com.google.android.material:material:${Versions.material}"
    //const val napier = "io.github.aakira:napier:${Versions.napier}"

    ///Here need to define the UI
    object Compose {
        //const val ui = "androidx.compose.ui:ui:${Versions.compose_version}"
    }

    ///Here need to define the Coroutines Lib
    object Coroutines {
       /// const val android = "org.jetbrains.kotlinx:kotlinx-coroutines-android:${Versions.coroutines}"
    }

    ///Here need to define the JetBrains packages
    object JetBrains {
        ///const val datetime = "org.jetbrains.kotlinx:kotlinx-datetime:${Versions.kotlinxDateTime}"
    }
}

